# Shifra Nuha Technologies — Logo Asset Library

## Files in this package

| File | Use case |
|------|----------|
| `01-icon-only.svg` | Favicon, app icon, profile photo, LinkedIn avatar, embossing, stamp |
| `02-horizontal-logo.svg` | Website header, email signature, letterhead, LinkedIn banner |
| `03-vertical-logo.svg` | Business cards (centre), presentation title slides, posters |
| `04-monochrome-logo.svg` | Single-ink print, newspaper ads, fax, legal documents, rubber stamp |
| `05-dark-background-logo.svg` | Dark website hero, presentations, pitch decks, dark-mode UI, merchandise |
| `06-icon-dark-bg.svg` | Dark-mode favicon, app icon on dark surfaces |

---

## How to open in Figma

1. Open Figma → **New file**
2. Press **Ctrl+Shift+K** (Windows) or **Cmd+Shift+K** (Mac) → import the SVG file
3. Or drag-and-drop the `.svg` file directly onto the Figma canvas
4. All paths are fully editable vectors

## How to open in Adobe Illustrator

1. **File → Open** → select the `.svg` file
2. All elements are live vector paths — fully editable

---

## Exporting PNG from Figma

1. Select the logo frame/group
2. Right panel → **Export** → click **+**
3. Set: `1x` (standard), `2x` (retina), `3x` (high-res)
4. Format: **PNG**
5. Click **Export**

## Exporting PNG from Illustrator

1. **File → Export → Export for Screens**
2. Select scales: `1x`, `2x`, `3x`
3. Format: **PNG**
4. Export

## Exporting PDF (for print/letterhead)

- **Figma**: Export → Format: **PDF**
- **Illustrator**: File → Save As → **Adobe PDF**

---

## Colour reference

| Name | Hex | Usage |
|------|-----|-------|
| Deep Navy | `#0F172A` | Primary text, monochrome mark |
| Brand Blue | `#1E3A8A` | Mark fill, icon container |
| Active Blue | `#2563EB` | CTAs, links, interactive elements |
| Signal Blue | `#3B82F6` | Accent nodes in mark (light bg) |
| Light Blue | `#60A5FA` | Accent nodes in mark (dark bg) |
| Sky Blue | `#93C5FD` | "TECHNOLOGIES" text on dark bg |
| White | `#FFFFFF` | Background, mark strokes |

---

## Clear space rule

Always maintain a minimum clear space equal to **half the mark width** on all four sides.
Never place the mark directly against an edge or other element.

## Minimum size

- **Digital:** 20px height
- **Print:** 6mm height

---

## Do not

- Stretch or distort the mark
- Change the colours outside the approved palette
- Add drop shadows, outlines, or effects
- Place the light-background version on dark surfaces (use `05` or `06` instead)
- Recreate the mark in a different font or style
